(function() {
    'use strict';

    let isEnabled = false;
    let isInitialized = false;

    chrome.storage.sync.get('statsCollectorEnabled', (data) => {
        isEnabled = data.statsCollectorEnabled !== false;
        if (isInitialized) { trackCampaignId(); checkLoadingState(); }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes.prismaDiagnostics && !Object.keys(changes.prismaDiagnostics.newValue?.days || {}).length) {
            clearDiagnostics();
            cancelPendingSave(null);
            if (isInitialized) checkDiagnostics();
        }
        if (area === 'local' && changes.campaignStatsSnapshots && !changes.campaignStatsSnapshots.newValue?.length) {
            lastSnapshotFingerprint = '';
        }
        if (area === 'sync' && changes.statsCollectorEnabled) {
            isEnabled = changes.statsCollectorEnabled.newValue !== false;
            if (!isEnabled) {
                cancelPendingSave();
                clearDiagnostics();
                loadingSpinnerStartTime = null;
                loadingSpinnerArea = '';
            } else if (isInitialized) {
                lastTrackedCampaignId = '';
                trackCampaignId();
                checkLoadingState();
            }
        }
    });

    // --- Utility function to track stats ---
    function trackStat(type, value) {
        if (!isEnabled) return;

        try {
            const messageResult = chrome.runtime.sendMessage({
                action: 'TRACK_STAT',
                type: type,
                value: value
            });
            Promise.resolve(messageResult)
                .then(response => {
                    if (response?.status === 'error') {
                        console.error('[Stats Collector] Stat was not saved:', response.message || 'Unknown background error.');
                    }
                })
                .catch(error => {
                    if (!String(error?.message || error).includes('Extension context invalidated')) {
                        console.error('[Stats Collector] Error sending stat:', error);
                    }
                });
        } catch (error) {
            // Silence "Extension context invalidated" errors
            if (!error.message.includes('Extension context invalidated')) {
                console.error('[Stats Collector] Error sending stat:', error);
            }
        }
    }

    // --- 1. Track Unique Campaign IDs ---
    let lastTrackedCampaignId = '';
    let lastSnapshotFingerprint = '';
    function trackCampaignSnapshot() {
        if (!isEnabled || getVisibleSpinners().length) return;
        const id = new URLSearchParams(window.location.hash.slice(1)).get('campaign-id');
        if (!id) return;
        const renderedId = document.querySelector('.buy-details-wrapper, .buy-details-background')?.textContent?.match(/\bCP[A-Z0-9-]+\b/i)?.[0];
        if (!renderedId || renderedId.toLowerCase() !== id.toLowerCase()) return;
        const snapshot = window.campaignHistoryFeature?.getCampaignSnapshot?.();
        if (!snapshot?.key || snapshot.campaignId !== id) return;
        const exactMoney = selector => {
            const text = (document.querySelector(selector)?.textContent?.trim() || '')
                .replace(/\s+(?:budget|buy total \(billable amount\))$/i, '');
            // Never infer money from rounded K/M labels or mix currencies.
            if (!/^(?:£|GBP\s*)\s*(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,2})?$/.test(text)) return null;
            return Number(text.replace(/GBP|£|,|\s/g, ''));
        };
        const budgetType = document.querySelector('[data-cy="budget-type-label"]')?.textContent?.trim();
        const value = {
            key: snapshot.key, clientName: snapshot.clientName || '',
            supplier: snapshot.supplier || '',
            budget: /total client cost/i.test(budgetType || '') ? exactMoney('[data-cy="budget-amount"]') : null,
            booked: /total client cost/i.test(budgetType || '') ? exactMoney('[data-cy="budget-purchased"]') : null
        };
        const fingerprint = JSON.stringify(value);
        if (fingerprint === lastSnapshotFingerprint) return;
        lastSnapshotFingerprint = fingerprint;
        trackStat('CAMPAIGN_SNAPSHOT', value);
    }
    function trackCampaignId() {
        if (!isEnabled) return;
        trackCampaignSnapshot();
        const campaignIdMatch = window.location.href.match(/campaign-id=([^&]+)/);
        const campaignId = campaignIdMatch?.[1] ? decodeURIComponent(campaignIdMatch[1]) : '';
        if (!campaignId) {
            lastTrackedCampaignId = '';
            return;
        }
        // Prisma can rewrite route parameters repeatedly during an initial
        // campaign render. A visit is a campaign-level event, not a URL-level
        // event, so repeated route updates must not queue duplicate storage
        // writes for the same campaign.
        if (campaignId === lastTrackedCampaignId) return;
        lastTrackedCampaignId = campaignId;
        trackStat('CAMPAIGN_VISIT', campaignId);
        console.log(`[Stats Collector] Campaign tracked: ${campaignId}`);
    }

    let areaUrl = window.location.href;
    let entryPhase = 'startup';
    let entryPhaseSawLoading = false;
    function getPrismaArea(url = window.location.href) {
        let params, parsedUrl;
        try {
            parsedUrl = new URL(url, window.location.origin);
            params = new URLSearchParams(parsedUrl.hash.replace(/^#/, ''));
        } catch {
            return 'unclassified';
        }
        if (url === window.location.href && areaUrl !== url) {
            areaUrl = url;
            entryPhase = 'navigation';
            entryPhaseSawLoading = false;
        }
        if (parsedUrl.pathname.startsWith('/mo-op-discovery/')) return 'session';

        const app = (params.get('osPspId') || '').toLowerCase();
        const module = (params.get('ptb-mod') || '').toLowerCase();
        const context = (params.get('ptb-ctx') || '').toLowerCase();
        const route = (params.get('route') || '').toLowerCase();
        const showOrders = params.get('showOrders') === 'true';

        if (app === 'cm-dashboard' || route === 'campaigns') return 'home';
        if (context === 'actualize' || route === 'actualize') return 'actualise';
        if (app === 'prsm-cm-ord' || showOrders || context === 'ordersummary') return 'orders';
        if (module === 'plan') return 'plan';
        if (module === 'traffic') return 'traffic';
        if (module === 'analyze') return 'analyse';
        if (module === 'buy') return 'buy';
        // Only a bare application entry can be an opening/navigation shell.
        // An unknown section identifier is a real classification gap, not a transition.
        const isEntry = /^\/campaign-management\/?$/.test(parsedUrl.pathname) &&
            !['osPspId', 'ptb-mod', 'ptb-ctx', 'route', 'campaign-id', 'osModalId'].some(key => params.get(key));
        return isEntry && url === window.location.href ? entryPhase : 'unclassified';
    }

    // Independent intervals: overlapping page indicators form one observation.
    const diagnosticIntervals = new Map();
    const interruptedIndicators = new Set();
    let diagnosticRoute = location.href;
    function finishDiagnostic(signal, outcome) {
        const active = diagnosticIntervals.get(signal);
        if (!active) return;
        diagnosticIntervals.delete(signal);
        clearTimeout(active.timer);
        if (active.timedOut) return;
        trackStat('PERFORMANCE_SAMPLE', { timestamp: Date.now(), signal, area: active.area,
            duration: Math.min(300000, Math.max(0, performance.now() - active.start)), outcome });
    }
    function clearDiagnostics(outcome) {
        [...diagnosticIntervals.keys()].forEach(signal => {
            if (outcome) finishDiagnostic(signal, outcome);
            else { clearTimeout(diagnosticIntervals.get(signal).timer); diagnosticIntervals.delete(signal); }
        });
    }
    function checkDiagnostics(state = window.loadingMonitor?.getState?.()) {
        if (!isEnabled || !state) return;
        if (document.hidden) { interruptHiddenDiagnostics(); return; }
        if (diagnosticRoute !== location.href) { clearDiagnostics('interrupted'); diagnosticRoute = location.href; }
        const states = {
            page_indicator: !!(state.pageVisibleSpinners?.length || state.pageVisibleSkeletons?.length),
            side_panel_indicator: !!(state.sidePanelVisibleSpinners?.length || state.sidePanelVisibleSkeletons?.length)
        };
        Object.entries(states).forEach(([signal, visible]) => {
            if (!visible) interruptedIndicators.delete(signal);
            if (interruptedIndicators.has(signal)) return;
            const active = diagnosticIntervals.get(signal);
            if (active && active.area !== getPrismaArea()) finishDiagnostic(signal, 'interrupted');
            if (!visible) finishDiagnostic(signal, 'completed');
            else if (!diagnosticIntervals.has(signal)) {
                const interval = { start: performance.now(), area: getPrismaArea(), timer: null };
                // Keep a sentinel after timeout until the indicator disappears.
                interval.timer = setTimeout(() => {
                    finishDiagnostic(signal, 'timed_out');
                    diagnosticIntervals.set(signal, { ...interval, timedOut: true, timer: null });
                }, 300000);
                diagnosticIntervals.set(signal, interval);
            }
        });
    }

    // --- 2. Track Loading Spinner Time ---
    let loadingSpinnerStartTime = null;
    let loadingSpinnerArea = '';
    function getVisibleSpinners(state) {
        if (Array.isArray(state?.visibleSpinners)) return state.visibleSpinners;
        if (window.loadingMonitor?.getState) {
            return window.loadingMonitor.getState().visibleSpinners;
        }
        return window.utils.findVisibleLoadingSpinners();
    }

    function recordLoadingSegment(endedAt = Date.now()) {
        if (loadingSpinnerStartTime === null) return;
        const duration = (endedAt - loadingSpinnerStartTime) / 1000;
        const area = loadingSpinnerArea || getPrismaArea();
        loadingSpinnerStartTime = null;
        loadingSpinnerArea = '';
        if (duration > 0) trackStat('LOADING_TIME', { seconds: duration, area });
    }

    function checkLoadingState(state) {
        state ||= window.loadingMonitor?.getState?.();
        // Observe URL changes before classifying either diagnostic or legacy time.
        getPrismaArea();
        checkDiagnostics(state);
        if (!isEnabled || document.hidden) {
            loadingSpinnerStartTime = null;
            loadingSpinnerArea = '';
            return;
        }
        const hasVisibleSpinner = getVisibleSpinners(state).length > 0;
        if (!hasVisibleSpinner) trackCampaignSnapshot();
        const currentArea = getPrismaArea();

        if (hasVisibleSpinner && loadingSpinnerStartTime === null) {
            loadingSpinnerStartTime = Date.now();
            loadingSpinnerArea = currentArea;
            console.log('[Stats Collector] Loading spinner detected. Timer started.');
        } else if (hasVisibleSpinner && loadingSpinnerArea !== currentArea) {
            const areaChangedAt = Date.now();
            recordLoadingSegment(areaChangedAt);
            loadingSpinnerStartTime = areaChangedAt;
            loadingSpinnerArea = currentArea;
        } else if (!hasVisibleSpinner && loadingSpinnerStartTime !== null) {
            const duration = (Date.now() - loadingSpinnerStartTime) / 1000;
            console.log(`[Stats Collector] Loading finished. Duration: ${duration.toFixed(2)}s`);
            recordLoadingSegment();
        }
        const hasIndicator = hasVisibleSpinner || state?.pageVisibleSkeletons?.length || state?.sidePanelVisibleSkeletons?.length;
        if (hasIndicator) entryPhaseSawLoading = true;
        else if (entryPhaseSawLoading) entryPhase = 'unclassified';
    }

    function finishActiveLoadingMeasurement() {
        if (!isEnabled || loadingSpinnerStartTime === null) return;
        recordLoadingSegment();
    }

    // Observe native placement acknowledgements only while a user save is pending.
    // A closed form, spinner disappearance or generic "Success" is not proof.
    const NATIVE_NOTICE = '.toast-success, .toast-error, .alert-success, .alert-danger, [role="alert"], [role="status"]';
    let pendingSave = null;
    let saveObserver = null;
    let saveTimeout = null;
    function finishSaveDiagnostic(outcome) {
        if (!pendingSave?.diagnosticActive) return;
        pendingSave.diagnosticActive = false;
        if (outcome && isEnabled) trackStat('PERFORMANCE_SAMPLE', { timestamp: Date.now(), signal: 'placement_save', area: pendingSave.area, duration: Math.min(300000, Math.max(0, performance.now() - pendingSave.startedAt)), outcome });
    }
    function interruptHiddenDiagnostics() {
        clearDiagnostics('interrupted');
        interruptedIndicators.add('page_indicator');
        interruptedIndicators.add('side_panel_indicator');
        // Keep watching for the real save acknowledgement so existing save counts
        // remain correct, but this operation can no longer supply a completed timing.
        finishSaveDiagnostic('interrupted');
    }
    function handleDiagnosticVisibility() {
        if (document.hidden) {
            interruptHiddenDiagnostics();
            finishActiveLoadingMeasurement();
        } else checkLoadingState();
    }
    function cancelPendingSave(outcome = 'interrupted') {
        finishSaveDiagnostic(outcome);
        saveObserver?.disconnect();
        saveObserver = null;
        clearTimeout(saveTimeout);
        saveTimeout = null;
        pendingSave = null;
    }

    function beginPlacementSave(button) {
        if (button.disabled || button.getAttribute('aria-disabled') === 'true' || pendingSave) return;
        const campaignId = new URLSearchParams(location.hash.slice(1)).get('campaign-id');
        if (!campaignId) return;
        const form = button.closest('[role="dialog"], .modal, form');
        const heading = form?.querySelector('h1, h2, h3, .modal-title')?.textContent || form?.getAttribute('aria-label') || '';
        if (!/\bplacement\b/i.test(heading)) return;
        const mode = /^(?:add|new|create) placement\b/i.test(heading.trim()) ? 'created'
            : /^edit placement\b/i.test(heading.trim()) ? 'updated' : 'other';
        const baseline = new WeakMap();
        document.querySelectorAll(NATIVE_NOTICE).forEach(node => baseline.set(node, node.textContent));
        pendingSave = { startedAt: performance.now(), area: getPrismaArea(), campaignId, mode, id: crypto.randomUUID(), baseline, diagnosticActive: !document.hidden };
        saveObserver = new MutationObserver(records => {
            if (!pendingSave || !isEnabled) return;
            if (new URLSearchParams(location.hash.slice(1)).get('campaign-id') !== pendingSave.campaignId) {
                cancelPendingSave();
                return;
            }
            const notices = new Set();
            records.forEach(record => {
                const root = record.target.nodeType === Node.ELEMENT_NODE ? record.target : record.target.parentElement;
                const parent = root?.closest?.(NATIVE_NOTICE);
                if (parent) notices.add(parent);
                record.addedNodes.forEach(node => {
                    if (node.nodeType !== Node.ELEMENT_NODE) return;
                    if (node.matches(NATIVE_NOTICE)) notices.add(node);
                    node.querySelectorAll(NATIVE_NOTICE).forEach(notice => notices.add(notice));
                });
            });
            for (const notice of notices) {
                if (notice.closest('[id^="toolshed"], [id^="ops-toolshed"], .otf-toast') || notice.hidden || notice.getAttribute('aria-hidden') === 'true' || getComputedStyle(notice).display === 'none' || getComputedStyle(notice).visibility === 'hidden') continue;
                const text = notice.textContent.replace(/\s+/g, ' ').trim();
                if (pendingSave.baseline.get(notice) === notice.textContent) continue;
                if (/\bplacement\b.*\b(?:failed|error|could not|cannot|unable)\b|\b(?:failed|unable)\b.*\bplacement\b/i.test(text)) {
                    cancelPendingSave('error');
                    return;
                }
                const match = text.match(/^placement(?:\s+[A-Z0-9-]+)?\s+(?:(?:has been|was)\s+)?(?:(successfully)\s+)?(created|added|updated|saved)(?:\s+(successfully))?[.!]?$/i);
                if (!match || (!match[1] && !match[3] && !notice.matches('.toast-success, .alert-success'))) continue;
                const verb = match[2].toLowerCase();
                const kind = ['created', 'added'].includes(verb) ? 'created' : verb === 'updated' ? 'updated' : pendingSave.mode;
                const value = { eventId: pendingSave.id, kind };
                cancelPendingSave('completed');
                trackStat('PLACEMENT_CONFIRMED', value);
                return;
            }
        });
        saveObserver.observe(document.body, { childList: true, subtree: true, characterData: true });
        saveTimeout = setTimeout(() => cancelPendingSave('timed_out'), 20000);
    }

    // --- 3. Track Click Events (Save Placements & Reconciliations) ---
    function handleClickEvents(event) {
        if (!isEnabled) return;
        // The exact amounts may appear only after opening Prisma's budget popover.
        if (event.target.closest('#campaign-budget-overview-container')) {
            window.setTimeout(trackCampaignSnapshot, 500);
        }

        // Track Placement Saves
        const saveButton = event.target.closest('#btn-save, #btn-save-and-add-another');
        if (saveButton) beginPlacementSave(saveButton);

        // Track Reconciliations (Ok to Pay = Yes)
        if (event.target.id === 'ok-to-pay-yes-button') {
            console.log('[Stats Collector] Reconciliation clicked.');
            trackStat('RECONCILIATION', 1);
        }

        // Track Reconciliations via Cost Source Dropdown
        // (User selects an item which changes "Ok to Pay" to Yes)
        const costSourceLink = event.target.closest('.handle-cost-source-selection-div li a[role="menuitem"]');
        if (costSourceLink) {
            console.log('[Stats Collector] Cost Source selection detected (Reconciliation).');
            trackStat('RECONCILIATION', 1);
        }
    }

    // --- Main Initialization ---
    let unsubscribeLoadingMonitor = null;

    function startLoadingMeasurements() {
        if (unsubscribeLoadingMonitor || !window.loadingMonitor?.subscribe) return;
        unsubscribeLoadingMonitor = window.loadingMonitor.subscribe(checkLoadingState);
    }

    function stopLoadingMeasurements() {
        clearDiagnostics('interrupted');
        cancelPendingSave();
        finishActiveLoadingMeasurement();
        unsubscribeLoadingMonitor?.();
        unsubscribeLoadingMonitor = null;
    }
    function initializeStatsCollector() {
        if (isInitialized) return;

        // Share the existing monitor so statistics stay independent of Loading Facts.
        startLoadingMeasurements();

        // Use event delegation for buttons
        document.body.addEventListener('click', handleClickEvents, true);
        window.addEventListener('pagehide', stopLoadingMeasurements);
        window.addEventListener('pageshow', startLoadingMeasurements);
        document.addEventListener('visibilitychange', handleDiagnosticVisibility);
        const handleRouteChange = () => { clearDiagnostics('interrupted'); cancelPendingSave(); trackCampaignId(); checkLoadingState(); };
        window.addEventListener('hashchange', handleRouteChange);
        window.addEventListener('popstate', handleRouteChange);
        trackCampaignId();

        isInitialized = true;
        console.log("Stats Collector Initialized");
    }

    window.statsCollector = {
        initialize: initializeStatsCollector,
        trackCampaignId: trackCampaignId,
        checkLoadingState,
        getPrismaArea
    };

})();
