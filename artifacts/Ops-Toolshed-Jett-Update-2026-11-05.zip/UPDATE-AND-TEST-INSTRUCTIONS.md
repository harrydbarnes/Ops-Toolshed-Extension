# Jett update and per-user writer pilot

## Update the existing extension

1. Finish any current tracker save and close the Reccies panel.
2. Extract the extension ZIP.
3. Copy the extension files into the exact folder Chrome already loads on Jett’s laptop. Choose Replace existing files. The manifest.json file must be directly inside that existing folder.
4. Open chrome://extensions in the same work Chrome profile and click Reload on the existing Ops Toolshed card.
5. Reload Prisma and reopen Reccies. Choose Refresh tracker from Google Sheet.

Use the existing installation and folder. Removing the extension can clear its saved tracker data. Loading another extracted folder can create a separate extension entry.

## What is included in the current extension update

- Saves check for a final result automatically and offer clearer busy/expired-preview recovery.
- Save previews survive the extension background worker restarting.
- Mark Yes can show live comments and offer removal. Automatic comment removal is a separate opt-in.
- Verification checks filtered rows first, followed by the rest of your assigned rows. Additional checks do not automatically change the tracker.
- A visible tracker refresh action, improved progress synchronisation and saved search/source preferences.
- The selected name appears in the Reccies heading. Progress shows the report month, refresh timestamp and working-days percentage.
- Main Tracker counts the following month’s first five weekdays. Early Recs uses the report month. Weekends are excluded.
- Verification guidance appears in a delayed tooltip. Tracker popups have red close controls and simpler final save results.

## Per-user writer pilot

This is a separate sample-sheet test of Google authorisation and edit-history attribution. The normal Reccies tracker uses the existing writer during the pilot.

### Before sending the pilot to Jett

Harry must configure and deploy the isolated Apps Script service, authorise it, create the sample sheet, and give Jett Editor access to that sample sheet. The pilot ZIP must contain the configured service URL. These setup steps are currently waiting for explicit approval of the Google email and Sheets OAuth scopes.

### Jett’s steps once the configured pilot is ready

1. Update the existing extension using the steps above.
2. Open Reccies, expand Debug and choose Test per-user writer on a sample sheet.
3. Choose Open Google authorisation. Select your work account and review Google’s requested permissions. Google’s Sheets scope is broad, even though this test targets its separate sample sheet. If company policy blocks it, send Harry the message rather than bypassing it.
4. When Google says connected, return to the test tab and choose Check connection / result.
5. Confirm that Connected and executing as shows your work email.
6. Choose Prepare my sample row. It should show a row number and Status No.
7. Tick the account confirmation, then choose Mark sample Yes.
8. Wait for Saved and read back. If the request is uncertain, choose Check connection / result before attempting another update.
9. Choose Open sample sheet. Right-click the Status cell in your row, choose Show edit history and check the email shown.
10. Download test result and send that JSON plus a screenshot of the cell history to Harry internally.

A passed result needs Jett’s email in both the connection result and Google’s cell edit history. The sample comment should remain present.

This test establishes per-user authorisation and an extension-origin sample write. It does not establish that the private production audit workbook is accessible under Jett’s account. That remains part of a later production migration.
